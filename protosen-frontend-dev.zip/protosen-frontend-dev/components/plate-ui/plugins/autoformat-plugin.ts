"use client";

import type { SlateEditor } from "@udecode/plate";
import type {
  AutoformatBlockRule,
  AutoformatRule,
} from "@udecode/plate-autoformat";

import { ElementApi, isType } from "@udecode/plate";
import {
  autoformatArrow,
  autoformatLegal,
  autoformatLegalHtml,
  autoformatMath,
  autoformatPunctuation,
  autoformatSmartQuotes,
} from "@udecode/plate-autoformat";
import { AutoformatPlugin } from "@udecode/plate-autoformat/react";
import {
  BoldPlugin,
  CodePlugin,
  ItalicPlugin,
  StrikethroughPlugin,
  SubscriptPlugin,
  SuperscriptPlugin,
  UnderlinePlugin,
} from "@udecode/plate-basic-marks/react";
import { BlockquotePlugin } from "@udecode/plate-block-quote/react";

import { HEADING_KEYS } from "@udecode/plate-heading";
import { HighlightPlugin } from "@udecode/plate-highlight/react";
import { HorizontalRulePlugin } from "@udecode/plate-horizontal-rule/react";
import {
  INDENT_LIST_KEYS,
  ListStyleType,
  toggleIndentList,
} from "@udecode/plate-indent-list";
import { openNextToggles, TogglePlugin } from "@udecode/plate-toggle/react";
import { ParagraphPlugin } from "@udecode/plate/react";
import { toggleList, unwrapList } from "@udecode/plate-list";
import {
  BulletedListPlugin,
  ListItemPlugin,
  NumberedListPlugin,
  TodoListPlugin,
} from "@udecode/plate-list/react";

export const preFormat: AutoformatBlockRule["preFormat"] = (editor) =>
  unwrapList(editor);

export const format = (editor: SlateEditor, customFormatting: any) => {
  if (editor.selection) {
    const parentEntry = editor.api.parent(editor.selection);

    if (!parentEntry) return;

    const [node] = parentEntry;

    if (ElementApi.isElement(node)) {
      customFormatting();
    }
  }
};

export const formatList = (editor: SlateEditor, elementType: string) => {
  format(editor, () =>
    toggleList(editor, {
      type: elementType,
    })
  );
};

export const autoformatMarks: AutoformatRule[] = [
  {
    match: "***",
    mode: "mark",
    type: [BoldPlugin.key, ItalicPlugin.key],
  },
  {
    match: "__*",
    mode: "mark",
    type: [UnderlinePlugin.key, ItalicPlugin.key],
  },
  {
    match: "__**",
    mode: "mark",
    type: [UnderlinePlugin.key, BoldPlugin.key],
  },
  {
    match: "___***",
    mode: "mark",
    type: [UnderlinePlugin.key, BoldPlugin.key, ItalicPlugin.key],
  },
  {
    match: "**",
    mode: "mark",
    type: BoldPlugin.key,
  },
  {
    match: "__",
    mode: "mark",
    type: UnderlinePlugin.key,
  },
  {
    match: "*",
    mode: "mark",
    type: ItalicPlugin.key,
  },
  {
    match: "_",
    mode: "mark",
    type: ItalicPlugin.key,
  },
  {
    match: "~~",
    mode: "mark",
    type: StrikethroughPlugin.key,
  },
  {
    match: "^",
    mode: "mark",
    type: SuperscriptPlugin.key,
  },
  {
    match: "~",
    mode: "mark",
    type: SubscriptPlugin.key,
  },
  {
    match: "==",
    mode: "mark",
    type: HighlightPlugin.key,
  },
  {
    match: "≡",
    mode: "mark",
    type: HighlightPlugin.key,
  },
  {
    match: "`",
    mode: "mark",
    type: CodePlugin.key,
  },
];

export const autoformatBlocks: AutoformatRule[] = [
  {
    match: "# ",
    mode: "block",
    type: HEADING_KEYS.h1,
  },
  {
    match: "## ",
    mode: "block",
    type: HEADING_KEYS.h2,
  },
  {
    match: "### ",
    mode: "block",
    type: HEADING_KEYS.h3,
  },
  {
    match: "#### ",
    mode: "block",
    type: HEADING_KEYS.h4,
  },
  {
    match: "##### ",
    mode: "block",
    type: HEADING_KEYS.h5,
  },
  {
    match: "###### ",
    mode: "block",
    type: HEADING_KEYS.h6,
  },
  {
    match: "> ",
    mode: "block",
    type: BlockquotePlugin.key,
  },
  {
    match: "+ ",
    mode: "block",
    preFormat: openNextToggles,
    type: TogglePlugin.key,
  },
  {
    match: ["---", "—-", "___ "],
    mode: "block",
    type: HorizontalRulePlugin.key,
    format: (editor) => {
      editor.tf.setNodes({ type: HorizontalRulePlugin.key });
      editor.tf.insertNodes({
        children: [{ text: "" }],
        type: ParagraphPlugin.key,
      });
    },
  },
];

export const autoformatIndentLists: AutoformatRule[] = [
  {
    match: ["* ", "- "],
    mode: "block",
    type: "list",
    format: (editor) => {
      toggleIndentList(editor, {
        listStyleType: ListStyleType.Disc,
      });
    },
  },
  {
    match: [String.raw`^\d+\.$ `, String.raw`^\d+\)$ `],
    matchByRegex: true,
    mode: "block",
    type: "list",
    format: (editor) =>
      toggleIndentList(editor, {
        listStyleType: ListStyleType.Decimal,
      }),
  },
  {
    match: ["[] "],
    mode: "block",
    type: "list",
    format: (editor) => {
      toggleIndentList(editor, {
        listStyleType: INDENT_LIST_KEYS.todo,
      });
      editor.tf.setNodes({
        checked: false,
        listStyleType: INDENT_LIST_KEYS.todo,
      });
    },
  },
  {
    match: ["[x] "],
    mode: "block",
    type: "list",
    format: (editor) => {
      toggleIndentList(editor, {
        listStyleType: INDENT_LIST_KEYS.todo,
      });
      editor.tf.setNodes({
        checked: true,
        listStyleType: INDENT_LIST_KEYS.todo,
      });
    },
  },
];

export const autoformatLists: AutoformatRule[] = [
  {
    match: ["* ", "- "],
    mode: "block",
    preFormat,
    type: ListItemPlugin.key,
    format: (editor) => formatList(editor, BulletedListPlugin.key),
  },
  {
    match: [String.raw`^\d+\.$ `, String.raw`^\d+\)$ `],
    matchByRegex: true,
    mode: "block",
    preFormat,
    type: ListItemPlugin.key,
    format: (editor) => formatList(editor, NumberedListPlugin.key),
  },
  {
    match: "[] ",
    mode: "block",
    type: TodoListPlugin.key,
  },
  {
    match: "[x] ",
    mode: "block",
    type: TodoListPlugin.key,
    format: (editor) =>
      editor.tf.setNodes(
        { checked: true, type: TodoListPlugin.key },
        {
          match: (n) => editor.api.isBlock(n),
        }
      ),
  },
];

export const autoformatPlugin = AutoformatPlugin.configure({
  options: {
    enableUndoOnDelete: true,
    rules: [
      ...autoformatBlocks,
      ...autoformatMarks,
      ...autoformatSmartQuotes,
      ...autoformatPunctuation,
      ...autoformatLegal,
      ...autoformatLegalHtml,
      ...autoformatArrow,
      ...autoformatMath,
      ...autoformatIndentLists,
      ...autoformatLists,
    ],
  },
});
