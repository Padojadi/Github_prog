"use client";

import { Transition } from "@headlessui/react";
import { useSelector } from "@xstate/store/react";
import Link from "next/link";
import { useSelectedLayoutSegments } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { BsGear, BsHouses } from "react-icons/bs";
import { useAppProvider } from "@/app/app-provider";
import { isConferenceEnabled } from "@/features/conferences/lib/utils";
import useCurrentUser from "@/hooks/useCurrentUser";
import { links } from "@/lib/data";
import { hasPermission } from "@/lib/utils";
import { featureFlagStore } from "@/store/feature-flag-store";
import { getBreakpoint } from "../utils/utils";
import Icon2 from "./icons/icon2";
import Logo from "./logo";
import SidebarLink from "./sidebar-link";
import SidebarLinkGroup from "./sidebar-link-group";

export default function Sidebar() {
	const sidebar = useRef<HTMLDivElement>(null);
	const { sidebarOpen, setSidebarOpen } = useAppProvider();
	const [sidebarExpanded, setSidebarExpanded] = useState<boolean>(false);
	const segments = useSelectedLayoutSegments();
	const currentUser = useCurrentUser();
	const [breakpoint, setBreakpoint] = useState<string | undefined>(
		getBreakpoint(),
	);
	const expandOnly =
		!sidebarExpanded && (breakpoint === "lg" || breakpoint === "xl");

	const conferencesEnabled = isConferenceEnabled();

	const urlRestrictedToUsers = [
		"/panel/dashboard",
		"/panel/missions",
		"/panel/conferences",
		"/panel/honor-lounge/manage",
		"/panel/diplomatic/dashboard",
		"/panel/visas/dashboard",
		"/panel/registrations/dashboard",
		"/panel/exemptions/dashboard",
	];

	const urlRestrictedToAll = [
		"/panel/others",
		"/panel/users",
		"/panel/settings",
	];
	const userPermissions = currentUser.accessGroup?.permissions || [];
	const conferenceLinkedModules = [
		"/panel/conferences",
		"/panel/honor-lounge",
		"/panel/visas",
		"/panel/exonerations",
		"/panel/registrations",
	];
	const hasConferenceLinkedAccess =
		currentUser.isAdmin ||
		currentUser.isSuperAdmin ||
		hasPermission(userPermissions, [
			"ACCESS_CONFERENCE_MODULE",
			"ACCESS_HONOR_LOUNGE_MODULE",
		]);

	// close on click outside
	useEffect(() => {
		const clickHandler = ({ target }: { target: EventTarget | null }): void => {
			if (!sidebar.current) return;
			if (!sidebarOpen || sidebar.current.contains(target as Node)) return;
			setSidebarOpen(false);
		};
		document.addEventListener("click", clickHandler);
		return () => document.removeEventListener("click", clickHandler);
	});

	// close if the esc key is pressed
	useEffect(() => {
		const keyHandler = ({ keyCode }: { keyCode: number }): void => {
			if (!sidebarOpen || keyCode !== 27) return;
			setSidebarOpen(false);
		};
		document.addEventListener("keydown", keyHandler);
		return () => document.removeEventListener("keydown", keyHandler);
	});

	useEffect(() => {
		const handleBreakpoint = () => {
			setBreakpoint(getBreakpoint());
		};
		window.addEventListener("resize", handleBreakpoint);
		return () => {
			window.removeEventListener("resize", handleBreakpoint);
		};
	}, []);

	return (
		<div className={`min-w-fit ${sidebarExpanded ? "sidebar-expanded" : ""}`}>
			{/* Sidebar backdrop (mobile only) */}
			<Transition
				className="fixed inset-0 bg-slate-100 dark:bg-slate-900 bg-opacity-30 z-40 lg:hidden lg:z-auto"
				show={sidebarOpen}
				enter="transition-opacity ease-out duration-200"
				enterFrom="opacity-0"
				enterTo="opacity-100"
				leave="transition-opacity ease-out duration-100"
				leaveFrom="opacity-100"
				leaveTo="opacity-0"
				aria-hidden="true"
			/>

			{/* Sidebar */}
			<Transition
				show={sidebarOpen}
				unmount={false}
				as="div"
				id="sidebar"
				ref={sidebar}
				className="flex lg:!flex flex-col absolute z-40 left-0 top-0 lg:static lg:left-auto lg:top-auto lg:translate-x-0 h-[100dvh] overflow-y-scroll lg:overflow-y-auto no-scrollbar w-64 lg:w-20 lg:sidebar-expanded:!w-64 2xl:!w-64 shrink-0 bg-slate-200 dark:bg-slate-800 p-4 transition-all duration-200 ease-in-out"
				enterFrom="-translate-x-full"
				enterTo="translate-x-0"
				leaveFrom="translate-x-0"
				leaveTo="-translate-x-full"
			>
				{/* Sidebar header */}
				<div className="flex justify-start items-center gap-2 mb-10 pr-3 sm:px-2">
					{/* Close button */}
					<button
						type="button"
						className="lg:hidden text-foreground hover:text-slate-400"
						onClick={() => setSidebarOpen(!sidebarOpen)}
						aria-controls="sidebar"
						aria-expanded={sidebarOpen}
					>
						<span className="sr-only">Close sidebar</span>
						<svg
							className="w-6 h-6 fill-current"
							viewBox="0 0 24 24"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path d="M10.7 18.7l1.4-1.4L7.8 13H20v-2H7.8l4.3-4.3-1.4-1.4L4 12z" />
						</svg>
					</button>
					{/* Logo */}
					<Logo />
					<h1 className="uppercase text-1xl font-bold text-foreground">
						Protosen
					</h1>
				</div>

				{/* Links */}
				<div className="space-y-8">
					{/* Pages group */}
					<div>
						<h3 className="text-xs uppercase text-slate-500 font-semibold pl-3">
							<span
								className="hidden lg:block lg:sidebar-expanded:hidden 2xl:hidden text-center w-6"
								aria-hidden="true"
							>
								•••
							</span>
							<span className="lg:hidden lg:sidebar-expanded:block 2xl:block">
								Pages
							</span>
						</h3>
						<ul className="mt-3">
							{
								// Dashboard link
								!currentUser.isUser && (
									<li
										className={`px-3 py-2 rounded-sm mb-0.5 last:mb-0 group is-link-group`}
									>
										<Link
											href="/panel/dashboard"
											className={`block text-foreground/70 truncate transition duration-150 ${
												segments.includes("ecommerce")
													? "hover:text-foreground"
													: "hover:text-foreground"
											}`}
										>
											<div className="flex items-center justify-between">
												<div className="flex items-center">
													<BsHouses size={16} />
													<span className="text-sm font-medium ml-3 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">
														{"Tableau de bord"}
													</span>
												</div>
											</div>
										</Link>
									</li>
								)
							}

							{links.map((link) => {
								if (
									currentUser.isUser &&
									urlRestrictedToUsers.includes(link.href)
								) {
									return null;
								}
								if (
									!conferencesEnabled &&
									link.href === "/panel/conferences" &&
									!currentUser.isAdmin &&
									!currentUser.isSuperAdmin
								) {
									return null;
								}
								if (
									conferenceLinkedModules.includes(link.href) &&
									!hasConferenceLinkedAccess
								) {
									return null;
								}
								if (
									!hasPermission(userPermissions, link.accessPermissions) &&
									link.href === "/panel/diplomatic"
								) {
									return null;
								}
								if (
									!currentUser.isSuperAdmin &&
									urlRestrictedToAll.includes(link.href)
								) {
									return null;
								}
								return (
									<SidebarLinkGroup key={link.href}>
										{(handleClick, open) => {
											return (
												<>
													<a
														href="#0"
														className={`block text-foreground/70 hover:text-foreground truncate transition duration-150 `}
														onClick={(e) => {
															e.preventDefault();
															expandOnly
																? setSidebarExpanded(true)
																: handleClick();
														}}
													>
														<div className="flex items-center justify-between">
															<div className="flex items-center">
																{link.icon ? link.icon : <Icon2 />}
																<span className="text-sm font-medium ml-3 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">
																	{link.label}
																</span>
															</div>
															{/* Icon */}
															<div className="flex shrink-0 ml-2">
																<svg
																	className={`w-3 h-3 shrink-0 ml-1 fill-current text-foreground ${
																		open && "rotate-180"
																	}`}
																	viewBox="0 0 12 12"
																>
																	<path d="M5.9 11.4L.5 6l1.4-1.4 4 4 4-4L11.3 6z" />
																</svg>
															</div>
														</div>
													</a>
													<div className="lg:hidden lg:sidebar-expanded:block 2xl:block">
														<ul className={`pl-9 mt-1 ${!open && "hidden"}`}>
															{link?.children?.map((child) => {
																if (
																	currentUser.isUser &&
																	urlRestrictedToUsers.includes(child.href)
																) {
																	return null;
																}

																return !child.children ? (
																	<li
																		className="mb-1 last:mb-0"
																		key={child.href}
																	>
																		<SidebarLink href={child.href}>
																			<span className="text-sm font-medium lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">
																				{child.label}
																			</span>
																		</SidebarLink>
																	</li>
																) : (
																	<SidebarLinkGroup key={child.href} level={1}>
																		{(handleClick, open) => {
																			return (
																				<>
																					<a
																						href="#0"
																						className={`block text-foreground/70 hover:text-foreground truncate transition duration-150 `}
																						onClick={(e) => {
																							e.preventDefault();
																							expandOnly
																								? setSidebarExpanded(true)
																								: handleClick();
																						}}
																					>
																						<div className="flex items-center justify-between">
																							<div className="flex items-center">
																								<span className="text-sm font-medium lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">
																									{child.label}
																								</span>
																							</div>
																							{/* Icon */}
																							<div className="flex shrink-0 ml-2">
																								<svg
																									className={`w-3 h-3 shrink-0 ml-1 fill-current text-foreground ${
																										open && "rotate-180"
																									}`}
																									viewBox="0 0 12 12"
																								>
																									<path d="M5.9 11.4L.5 6l1.4-1.4 4 4 4-4L11.3 6z" />
																								</svg>
																							</div>
																						</div>
																					</a>
																					<div className="lg:hidden lg:sidebar-expanded:block 2xl:block">
																						<ul
																							className={`pl-6 mt-1 ${
																								!open && "hidden"
																							}`}
																						>
																							{child?.children?.map(
																								(child2) => {
																									return (
																										<li
																											className="mb-1 last:mb-0"
																											key={child2.href}
																										>
																											<SidebarLink
																												href={child2.href}
																											>
																												<span className="text-sm font-medium text-foreground lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">
																													{child2.label}
																												</span>
																											</SidebarLink>
																										</li>
																									);
																								},
																							)}
																						</ul>
																					</div>
																				</>
																			);
																		}}
																	</SidebarLinkGroup>
																);
															})}
														</ul>
													</div>
												</>
											);
										}}
									</SidebarLinkGroup>
								);
							})}
							{currentUser?.isSuperAdmin && (
								<li
									className={`px-3 py-2 rounded-sm mb-0.5 last:mb-0 group is-link-group`}
								>
									<Link
										href="/panel/settings"
										className={`block text-foreground/70 hover:text-foreground truncate transition duration-150 ${
											segments.includes("settings")
												? "hover:text-foreground"
												: "hover:text-foreground"
										}`}
									>
										<div className="flex items-center justify-between">
											<div className="flex items-center">
												<BsGear size={16} />
												<span className="text-sm font-medium ml-3 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">
													{"Paramètres"}
												</span>
											</div>
										</div>
									</Link>
								</li>
							)}
							{/* {currentUser?.isAdmin ||
                (currentUser?.isSuperAdmin && (
                  <li
                    className={`px-3 py-2 rounded-sm mb-0.5 last:mb-0 group is-link-group`}
                  >
                    <Link
                      href="/panel/users"
                      className={`block text-slate-200 truncate transition duration-150 ${
                        segments.includes("users")
                          ? "hover:text-slate-200"
                          : "hover:text-white"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <BsPeople size={24} />
                          <span className="text-sm font-medium ml-3 lg:opacity-0 lg:sidebar-expanded:opacity-100 2xl:opacity-100 duration-200">
                            {"Utilisateurs"}
                          </span>
                        </div>
                      </div>
                    </Link>
                  </li>
                ))} */}
						</ul>
					</div>
				</div>

				{/* Expand / collapse button */}
				<div className="pt-3 hidden lg:inline-flex 2xl:hidden justify-end mt-auto">
					<div className="px-3 py-2">
						<button
							type="button"
							onClick={() => setSidebarExpanded(!sidebarExpanded)}
						>
							<span className="sr-only">Expand / collapse sidebar</span>
							<svg
								className="w-6 h-6 fill-current sidebar-expanded:rotate-180"
								viewBox="0 0 24 24"
							>
								<path
									className="text-slate-400"
									d="M19.586 11l-5-5L16 4.586 23.414 12 16 19.414 14.586 18l5-5H7v-2z"
								/>
								<path className="text-slate-600" d="M3 23H1V1h2z" />
							</svg>
						</button>
					</div>
				</div>
			</Transition>
		</div>
	);
}
