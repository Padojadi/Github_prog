export type RegistrationFormType =
  | "DEMANDE"
  | "MUTATION"
  | "PERMIS"
  | "RETRAIT"
  | "CORRECTION";

export type RegistrationWorkflowStatus =
  | "SUBMITTED"
  | "AUTO_VERIFIED"
  | "AGENT_VALIDATED"
  | "ASSIGNED"
  | "NOTIFIED"
  | "WITHDRAWN"
  | "ARCHIVED"
  | "REJECTED";

export type RegistrationValidationDecision = "APPROVE" | "REJECT";

export type RegistrationRequest = {
  id: string;
  dossierNumber: string;
  formType: RegistrationFormType;
  applicantFirstName: string;
  applicantLastName: string;
  applicantEmail: string;
  applicantPhone?: string | null;
  organization?: string | null;
  subject: string;
  vehicleInfo?: Record<string, unknown> | null;
  supportingDocuments: string;
  currentStatus: RegistrationWorkflowStatus;
  automaticVerification?: { score?: number } | null;
  agentDecision?: RegistrationValidationDecision | null;
  agentNotes?: string | null;
  rejectionReason?: string | null;
  correctionNotes?: string | null;
  assignmentNumber?: string | null;
  permitNumber?: string | null;
  assignedAt?: string | null;
  notifiedAt?: string | null;
  withdrawnAt?: string | null;
  archivedAt?: string | null;
  createdBy: string;
  validatedBy?: string | null;
  assignedBy?: string | null;
  notifiedBy?: string | null;
  withdrawnBy?: string | null;
  archivedBy?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type RegistrationStatusHistory = {
  id: string;
  registrationRequestId: string;
  status: RegistrationWorkflowStatus;
  changedBy: string;
  notes?: string | null;
  metadata?: Record<string, unknown> | null;
  createdAt: string;
};

export type RegistrationListResponse = {
  currentPage: number;
  perPage: number;
  total: number;
  totalPages: number;
  data: RegistrationRequest[];
};

export type RegistrationKpiSummary = {
  total: number;
  submitted: number;
  autoVerified: number;
  agentValidated: number;
  assigned: number;
  notified: number;
  withdrawn: number;
  archived: number;
  rejected: number;
  rejectionRate: number;
  avgProcessingHours: number;
};

export type RegistrationSearchParams = {
  page?: number;
  limit?: number;
  search?: string;
  status?: RegistrationWorkflowStatus;
  formType?: RegistrationFormType;
  fromDate?: string;
  toDate?: string;
};

export type CreateRegistrationRequestPayload = {
  formType: RegistrationFormType;
  applicantFirstName: string;
  applicantLastName: string;
  applicantEmail: string;
  applicantPhone?: string;
  organization?: string;
  subject: string;
  vehicleInfo?: Record<string, unknown>;
  supportingDocuments: string;
};

export type ValidateRegistrationPayload = {
  decision: RegistrationValidationDecision;
  notes?: string;
  rejectionReason?: string;
};

export type NotifyRegistrationPayload = {
  channels: string[];
  notes?: string;
};

export type AssignRegistrationPayload = {
  assignmentNumber?: string;
  permitNumber?: string;
  notes?: string;
};

export type UpdateRegistrationRequestPayload = Partial<
  Pick<
    RegistrationRequest,
    | "formType"
    | "applicantFirstName"
    | "applicantLastName"
    | "applicantEmail"
    | "applicantPhone"
    | "organization"
    | "subject"
    | "supportingDocuments"
    | "correctionNotes"
  >
>;

export const getRegistrationStatusLabel = (status: RegistrationWorkflowStatus) => {
  if (status === "SUBMITTED") return "Soumise";
  if (status === "AUTO_VERIFIED") return "Vérifiée automatiquement";
  if (status === "AGENT_VALIDATED") return "Validée agent";
  if (status === "ASSIGNED") return "Attribuée";
  if (status === "NOTIFIED") return "Notifiée";
  if (status === "WITHDRAWN") return "Retirée";
  if (status === "ARCHIVED") return "Archivée";
  return "Rejetée";
};

export const getRegistrationStatusBadgeClasses = (status: RegistrationWorkflowStatus) => {
  if (status === "SUBMITTED") return "bg-slate-100 text-slate-700";
  if (status === "AUTO_VERIFIED") return "bg-blue-100 text-blue-700";
  if (status === "AGENT_VALIDATED") return "bg-indigo-100 text-indigo-700";
  if (status === "ASSIGNED") return "bg-emerald-100 text-emerald-700";
  if (status === "NOTIFIED") return "bg-amber-100 text-amber-700";
  if (status === "WITHDRAWN") return "bg-cyan-100 text-cyan-700";
  if (status === "ARCHIVED") return "bg-gray-200 text-gray-700";
  return "bg-red-100 text-red-700";
};
