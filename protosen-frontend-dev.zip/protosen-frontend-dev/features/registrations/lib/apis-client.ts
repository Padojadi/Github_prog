import { getSession } from "next-auth/react";
import { getApiErrorMessage } from "@/lib/api-status-codes";
import { BACKEND_URL_CONFERENCES } from "@/lib/constants";
import { createSafeError, ServerActionError } from "@/lib/errors";
import type {
  AssignRegistrationPayload,
  CreateRegistrationRequestPayload,
  NotifyRegistrationPayload,
  RegistrationKpiSummary,
  RegistrationListResponse,
  RegistrationRequest,
  RegistrationSearchParams,
  RegistrationStatusHistory,
  UpdateRegistrationRequestPayload,
  ValidateRegistrationPayload,
} from "../types";

const buildSearchParams = (params: Record<string, unknown>) => {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      query.append(key, String(value));
    }
  });
  return query;
};

const fetchWithAuth = async (url: string, init?: RequestInit) => {
  const session = await getSession();
  const token = session?.backendTokens?.accessToken;

  return fetch(url, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(init?.headers || {}),
    },
  });
};

const handleError = (response: Response, result: any, fallback: string) => {
  if (response.status === 401) {
    throw new ServerActionError(
      result?.code ? String(result?.code) : "401",
      result?.message || "Veuillez vous connecter",
    );
  }
  throw new ServerActionError(
    result?.code ? String(result?.code) : String(response.status),
    result?.code ? getApiErrorMessage(result?.code) : fallback,
  );
};

export const getRegistrationRequestsClient = async (
  params: RegistrationSearchParams = {},
) => {
  const query = buildSearchParams({
    page: params.page,
    limit: params.limit,
    search: params.search,
    status: params.status,
    formType: params.formType,
    fromDate: params.fromDate,
    toDate: params.toDate,
  });
  const url = `${BACKEND_URL_CONFERENCES}/registration${
    query.toString() ? `?${query.toString()}` : ""
  }`;

  try {
    const response = await fetchWithAuth(url);
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la récupération des demandes d'immatriculation.",
      );
    }
    return {
      data: result as RegistrationListResponse,
      status: "success",
      message: "Demandes d'immatriculation récupérées avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const getRegistrationRequestByIdClient = async (id: string) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}`;

  try {
    const response = await fetchWithAuth(url);
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la récupération de la demande d'immatriculation.",
      );
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Demande d'immatriculation récupérée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const getRegistrationHistoryClient = async (id: string) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}/history`;

  try {
    const response = await fetchWithAuth(url);
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la récupération de l'historique d'immatriculation.",
      );
    }
    return {
      data: result as RegistrationStatusHistory[],
      status: "success",
      message: "Historique d'immatriculation récupéré avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const createRegistrationRequestClient = async (
  payload: CreateRegistrationRequestPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration`;

  try {
    const response = await fetchWithAuth(url, {
      method: "POST",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la création de la demande d'immatriculation.",
      );
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Demande d'immatriculation créée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const updateRegistrationRequestClient = async (
  id: string,
  payload: UpdateRegistrationRequestPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la mise à jour de la demande d'immatriculation.",
      );
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Demande d'immatriculation mise à jour avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const verifyRegistrationRequestClient = async (
  id: string,
  payload: { automaticScore?: number; notes?: string },
) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}/verify`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la vérification automatique du dossier.",
      );
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Vérification automatique effectuée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const validateRegistrationRequestClient = async (
  id: string,
  payload: ValidateRegistrationPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}/validate-agent`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(response, result, "Erreur lors de la validation agent.");
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Validation agent effectuée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const assignRegistrationRequestClient = async (
  id: string,
  payload: AssignRegistrationPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}/assign`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(response, result, "Erreur lors de l'attribution du dossier.");
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Attribution du dossier effectuée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const notifyRegistrationRequestClient = async (
  id: string,
  payload: NotifyRegistrationPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}/notify`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(response, result, "Erreur lors de la notification du dossier.");
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Notification du dossier effectuée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const markRegistrationWithdrawnClient = async (id: string) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}/withdraw`;

  try {
    const response = await fetchWithAuth(url, { method: "PATCH" });
    const result = await response.json();
    if (!response.ok) {
      handleError(response, result, "Erreur lors de l'enregistrement du retrait.");
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Retrait enregistré avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const archiveRegistrationRequestClient = async (id: string) => {
  const url = `${BACKEND_URL_CONFERENCES}/registration/${id}/archive`;

  try {
    const response = await fetchWithAuth(url, { method: "PATCH" });
    const result = await response.json();
    if (!response.ok) {
      handleError(response, result, "Erreur lors de l'archivage du dossier.");
    }
    return {
      data: result as RegistrationRequest,
      status: "success",
      message: "Archivage effectué avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const getRegistrationKpisClient = async (params?: {
  fromDate?: string;
  toDate?: string;
}) => {
  const query = buildSearchParams({
    fromDate: params?.fromDate,
    toDate: params?.toDate,
  });
  const url = `${BACKEND_URL_CONFERENCES}/registration/kpis/summary${
    query.toString() ? `?${query.toString()}` : ""
  }`;

  try {
    const response = await fetchWithAuth(url);
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la récupération des KPI d'immatriculation.",
      );
    }
    return {
      data: result as RegistrationKpiSummary,
      status: "success",
      message: "KPI d'immatriculation récupérés avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};
