"use client";

import { useQuery } from "@tanstack/react-query";
import {
  getRegistrationHistoryClient,
  getRegistrationKpisClient,
  getRegistrationRequestByIdClient,
  getRegistrationRequestsClient,
} from "../lib/apis-client";
import type { RegistrationSearchParams } from "../types";

export function useGetRegistrationRequests(params: RegistrationSearchParams = {}) {
  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["registrations", "requests", params],
    queryFn: async () => getRegistrationRequestsClient(params),
    retry: 1,
  });

  return { data, isLoading, isFetching, error, refetch };
}

export function useGetRegistrationRequestById(id: string) {
  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["registrations", "request", id],
    queryFn: async () => getRegistrationRequestByIdClient(id),
    enabled: !!id,
    retry: 1,
  });

  return { data, isLoading, isFetching, error, refetch };
}

export function useGetRegistrationHistory(id: string) {
  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["registrations", "history", id],
    queryFn: async () => getRegistrationHistoryClient(id),
    enabled: !!id,
    retry: 1,
  });

  return { data, isLoading, isFetching, error, refetch };
}

export function useGetRegistrationKpis(params?: { fromDate?: string; toDate?: string }) {
  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["registrations", "kpis", params?.fromDate, params?.toDate],
    queryFn: async () => getRegistrationKpisClient(params),
    retry: 1,
  });

  return { data, isLoading, isFetching, error, refetch };
}
