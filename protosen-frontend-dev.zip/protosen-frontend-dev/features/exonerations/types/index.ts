export type ExonerationWorkflowStatus =
  | "SUBMITTED"
  | "AUTO_VERIFIED"
  | "DPCT_VALIDATED"
  | "CUSTOMS_VALIDATED"
  | "REJECTED"
  | "ISSUED"
  | "NOTIFIED";

export type ExonerationValidationDecision = "APPROVE" | "REJECT";

export type ExonerationRequest = {
  id: string;
  dossierNumber: string;
  applicantFirstName: string;
  applicantLastName: string;
  applicantEmail: string;
  applicantPhone?: string | null;
  organization?: string | null;
  titleType: string;
  requestReason: string;
  supportingDocuments: string;
  currentStatus: ExonerationWorkflowStatus;
  automaticVerification?: { score?: number } | null;
  dpctDecision?: ExonerationValidationDecision | null;
  dpctNotes?: string | null;
  customsDecision?: ExonerationValidationDecision | null;
  customsNotes?: string | null;
  rejectionReason?: string | null;
  exonerationNumber?: string | null;
  issuedAt?: string | null;
  expiryDate?: string | null;
  notifiedAt?: string | null;
  createdBy: string;
  dpctValidatedBy?: string | null;
  customsValidatedBy?: string | null;
  issuedBy?: string | null;
  notifiedBy?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type ExonerationStatusHistory = {
  id: string;
  exonerationRequestId: string;
  status: ExonerationWorkflowStatus;
  changedBy: string;
  notes?: string | null;
  metadata?: Record<string, unknown> | null;
  createdAt: string;
};

export type ExonerationListResponse = {
  currentPage: number;
  perPage: number;
  total: number;
  totalPages: number;
  data: ExonerationRequest[];
};

export type ExonerationKpiSummary = {
  total: number;
  submitted: number;
  autoVerified: number;
  dpctValidated: number;
  customsValidated: number;
  rejected: number;
  issued: number;
  notified: number;
  rejectionRate: number;
  avgProcessingHours: number;
};

export type ExonerationSearchParams = {
  page?: number;
  limit?: number;
  search?: string;
  status?: ExonerationWorkflowStatus;
  titleType?: string;
  fromDate?: string;
  toDate?: string;
};

export type CreateExonerationRequestPayload = {
  applicantFirstName: string;
  applicantLastName: string;
  applicantEmail: string;
  applicantPhone?: string;
  organization?: string;
  titleType: string;
  requestReason: string;
  supportingDocuments: string;
};

export type ValidateDpctPayload = {
  decision: ExonerationValidationDecision;
  notes?: string;
  rejectionReason?: string;
};

export type ValidateCustomsPayload = {
  decision: ExonerationValidationDecision;
  notes?: string;
  rejectionReason?: string;
};

export type NotifyExonerationPayload = {
  channels: string[];
  notes?: string;
};

export type EmitExonerationPayload = {
  exonerationNumber?: string;
  issuedAt?: string;
  expiryDate?: string;
  notes?: string;
};

export type UpdateExonerationRequestPayload = Partial<
  Pick<
    ExonerationRequest,
    | "applicantFirstName"
    | "applicantLastName"
    | "applicantEmail"
    | "applicantPhone"
    | "organization"
    | "titleType"
    | "requestReason"
    | "supportingDocuments"
  >
>;

export const getExonerationStatusLabel = (status: ExonerationWorkflowStatus) => {
  if (status === "SUBMITTED") return "Soumise";
  if (status === "AUTO_VERIFIED") return "Vérifiée automatiquement";
  if (status === "DPCT_VALIDATED") return "Validée DPCT";
  if (status === "CUSTOMS_VALIDATED") return "Validée Douane";
  if (status === "REJECTED") return "Rejetée";
  if (status === "ISSUED") return "Émise";
  return "Notifiée";
};

export const getExonerationStatusBadgeClasses = (status: ExonerationWorkflowStatus) => {
  if (status === "SUBMITTED") return "bg-slate-100 text-slate-700";
  if (status === "AUTO_VERIFIED") return "bg-blue-100 text-blue-700";
  if (status === "DPCT_VALIDATED") return "bg-indigo-100 text-indigo-700";
  if (status === "CUSTOMS_VALIDATED") return "bg-violet-100 text-violet-700";
  if (status === "REJECTED") return "bg-red-100 text-red-700";
  if (status === "ISSUED") return "bg-emerald-100 text-emerald-700";
  return "bg-amber-100 text-amber-700";
};
