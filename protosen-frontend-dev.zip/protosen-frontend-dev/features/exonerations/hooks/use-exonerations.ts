"use client";

import { useQuery } from "@tanstack/react-query";
import {
  getExonerationHistoryClient,
  getExonerationKpisClient,
  getExonerationRequestByIdClient,
  getExonerationRequestsClient,
} from "../lib/apis-client";
import type { ExonerationSearchParams } from "../types";

export function useGetExonerationRequests(params: ExonerationSearchParams = {}) {
  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["exonerations", "requests", params],
    queryFn: async () => getExonerationRequestsClient(params),
    retry: 1,
  });

  return { data, isLoading, isFetching, error, refetch };
}

export function useGetExonerationRequestById(id: string) {
  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["exonerations", "request", id],
    queryFn: async () => getExonerationRequestByIdClient(id),
    enabled: !!id,
    retry: 1,
  });

  return { data, isLoading, isFetching, error, refetch };
}

export function useGetExonerationHistory(id: string) {
  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["exonerations", "history", id],
    queryFn: async () => getExonerationHistoryClient(id),
    enabled: !!id,
    retry: 1,
  });

  return { data, isLoading, isFetching, error, refetch };
}

export function useGetExonerationKpis(params?: { fromDate?: string; toDate?: string }) {
  const { data, isLoading, isFetching, error, refetch } = useQuery({
    queryKey: ["exonerations", "kpis", params?.fromDate, params?.toDate],
    queryFn: async () => getExonerationKpisClient(params),
    retry: 1,
  });

  return { data, isLoading, isFetching, error, refetch };
}
