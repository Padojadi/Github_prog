import { getSession } from "next-auth/react";
import { getApiErrorMessage } from "@/lib/api-status-codes";
import { BACKEND_URL_CONFERENCES } from "@/lib/constants";
import { createSafeError, ServerActionError } from "@/lib/errors";
import type {
  CreateExonerationRequestPayload,
  EmitExonerationPayload,
  ExonerationKpiSummary,
  ExonerationListResponse,
  ExonerationRequest,
  ExonerationSearchParams,
  ExonerationStatusHistory,
  NotifyExonerationPayload,
  UpdateExonerationRequestPayload,
  ValidateCustomsPayload,
  ValidateDpctPayload,
} from "../types";

const buildSearchParams = (params: Record<string, unknown>) => {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      query.append(key, String(value));
    }
  });
  return query;
};

const fetchWithAuth = async (url: string, init?: RequestInit) => {
  const session = await getSession();
  const token = session?.backendTokens?.accessToken;

  return fetch(url, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(init?.headers || {}),
    },
  });
};

const handleError = (response: Response, result: any, fallback: string) => {
  if (response.status === 401) {
    throw new ServerActionError(
      result?.code ? String(result?.code) : "401",
      result?.message || "Veuillez vous connecter",
    );
  }
  throw new ServerActionError(
    result?.code ? String(result?.code) : String(response.status),
    result?.code ? getApiErrorMessage(result?.code) : fallback,
  );
};

export const getExonerationRequestsClient = async (
  params: ExonerationSearchParams = {},
) => {
  const query = buildSearchParams({
    page: params.page,
    limit: params.limit,
    search: params.search,
    status: params.status,
    titleType: params.titleType,
    fromDate: params.fromDate,
    toDate: params.toDate,
  });
  const url = `${BACKEND_URL_CONFERENCES}/exoneration${
    query.toString() ? `?${query.toString()}` : ""
  }`;

  try {
    const response = await fetchWithAuth(url);
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la récupération des demandes d'exonération.",
      );
    }
    return {
      data: result as ExonerationListResponse,
      status: "success",
      message: "Demandes d'exonération récupérées avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const getExonerationRequestByIdClient = async (id: string) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}`;

  try {
    const response = await fetchWithAuth(url);
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la récupération de la demande d'exonération.",
      );
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Demande d'exonération récupérée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const getExonerationHistoryClient = async (id: string) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}/history`;

  try {
    const response = await fetchWithAuth(url);
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la récupération de l'historique d'exonération.",
      );
    }
    return {
      data: result as ExonerationStatusHistory[],
      status: "success",
      message: "Historique d'exonération récupéré avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const createExonerationRequestClient = async (
  payload: CreateExonerationRequestPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration`;

  try {
    const response = await fetchWithAuth(url, {
      method: "POST",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la création de la demande d'exonération.",
      );
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Demande d'exonération créée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const updateExonerationRequestClient = async (
  id: string,
  payload: UpdateExonerationRequestPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la mise à jour de la demande d'exonération.",
      );
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Demande d'exonération mise à jour avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const verifyExonerationRequestClient = async (
  id: string,
  payload: { automaticScore?: number; notes?: string },
) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}/verify`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la vérification automatique du dossier TE.",
      );
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Vérification automatique effectuée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const validateExonerationDpctClient = async (
  id: string,
  payload: ValidateDpctPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}/validate-dpct`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(response, result, "Erreur lors de la validation DPCT.");
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Validation DPCT effectuée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const validateExonerationDouaneClient = async (
  id: string,
  payload: ValidateCustomsPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}/validate-douane`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(response, result, "Erreur lors de la validation Douane.");
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Validation Douane effectuée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const notifyExonerationRequestClient = async (
  id: string,
  payload: NotifyExonerationPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}/notify-rejection`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la notification de rejet du dossier TE.",
      );
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Notification de rejet envoyée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const emitExonerationRequestClient = async (
  id: string,
  payload: EmitExonerationPayload,
) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}/emit`;

  try {
    const response = await fetchWithAuth(url, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de l'émission du titre d'exonération.",
      );
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Titre d'exonération émis avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const markExonerationNotifiedClient = async (id: string) => {
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/${id}/mark-notified`;

  try {
    const response = await fetchWithAuth(url, { method: "PATCH" });
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors du marquage de notification du dossier TE.",
      );
    }
    return {
      data: result as ExonerationRequest,
      status: "success",
      message: "Notification du dossier TE enregistrée avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};

export const getExonerationKpisClient = async (params?: {
  fromDate?: string;
  toDate?: string;
}) => {
  const query = buildSearchParams({
    fromDate: params?.fromDate,
    toDate: params?.toDate,
  });
  const url = `${BACKEND_URL_CONFERENCES}/exoneration/kpis/summary${
    query.toString() ? `?${query.toString()}` : ""
  }`;

  try {
    const response = await fetchWithAuth(url);
    const result = await response.json();
    if (!response.ok) {
      handleError(
        response,
        result,
        "Erreur lors de la récupération des KPI d'exonération.",
      );
    }
    return {
      data: result as ExonerationKpiSummary,
      status: "success",
      message: "KPI d'exonération récupérés avec succès.",
    };
  } catch (error) {
    return createSafeError(error);
  }
};
