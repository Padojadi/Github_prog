import {
  BadRequestException,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import {
  ExonerationValidationDecision,
  ExonerationWorkflowStatus,
  Prisma,
} from '@prisma/client';
import { PrismaService } from 'src/config/prisma/prisma.service';
import { PaginationMeta } from 'src/core/dtos/paginationmeta';
import { User } from '../user/generated/user';
import {
  CreateExonerationRequestDto,
  EmitExonerationDto,
  ExonerationKpiFiltersDto,
  ExonerationRequestSearchDto,
  NotifyRejectionExonerationRequestDto,
  ValidateCustomsExonerationRequestDto,
  ValidateDpctExonerationRequestDto,
  VerifyExonerationRequestDto,
} from './dto/create-exoneration-request.dto';
import { UpdateExonerationRequestDto } from './dto/update-exoneration-request.dto';

@Injectable()
export class ExonerationService {
  constructor(private readonly prisma: PrismaService) {}

  private hasPermission(user: User, permission: string): boolean {
    return (user?.accessGroup?.permissions || []).includes(permission);
  }

  private canAccess(user: User): boolean {
    return (
      this.hasPermission(user, 'ACCESS_CONFERENCE_MODULE') ||
      user?.role === 'admin' ||
      user?.role === 'super_admin'
    );
  }

  private canManage(user: User): boolean {
    return (
      this.hasPermission(user, 'MANAGE_CONFERENCES') ||
      user?.role === 'admin' ||
      user?.role === 'super_admin'
    );
  }

  private parseDateInput(value?: string | Date) {
    if (!value) {
      return undefined;
    }
    const parsed = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(parsed.getTime())) {
      throw new BadRequestException('Format de date invalide.');
    }
    return parsed;
  }

  private async generateDossierNumber() {
    const year = new Date().getFullYear();
    const prefix = `TE-${year}-`;
    const count = await this.prisma.exonerationRequest.count({
      where: { dossierNumber: { startsWith: prefix } },
    });
    return `${prefix}${String(count + 1).padStart(5, '0')}`;
  }

  private async generateExonerationNumber() {
    const year = new Date().getFullYear();
    const prefix = `NTE-${year}-`;
    const count = await this.prisma.exonerationRequest.count({
      where: { exonerationNumber: { startsWith: prefix } },
    });
    return `${prefix}${String(count + 1).padStart(5, '0')}`;
  }

  private async createHistory(
    exonerationRequestId: string,
    status: ExonerationWorkflowStatus,
    changedBy: string,
    notes?: string,
    metadata?: Prisma.InputJsonValue,
  ) {
    await this.prisma.exonerationStatusHistory.create({
      data: {
        exonerationRequestId,
        status,
        changedBy,
        notes,
        metadata,
      },
    });
  }

  private async ensureExists(id: string) {
    const existing = await this.prisma.exonerationRequest.findUnique({
      where: { id },
    });
    if (!existing) {
      throw new NotFoundException("Demande d'exonération introuvable.");
    }
    return existing;
  }

  async create(user: User, dto: CreateExonerationRequestDto) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour créer une demande d'exonération.",
      );
    }

    try {
      const dossierNumber = await this.generateDossierNumber();
      const created = await this.prisma.exonerationRequest.create({
        data: {
          dossierNumber,
          applicantFirstName: dto.applicantFirstName.trim(),
          applicantLastName: dto.applicantLastName.trim(),
          applicantEmail: dto.applicantEmail.trim(),
          applicantPhone: dto.applicantPhone?.trim(),
          organization: dto.organization?.trim(),
          titleType: dto.titleType.trim(),
          requestReason: dto.requestReason.trim(),
          supportingDocuments: dto.supportingDocuments.trim(),
          createdBy: user.id,
          currentStatus: ExonerationWorkflowStatus.SUBMITTED,
        },
      });

      await this.createHistory(
        created.id,
        ExonerationWorkflowStatus.SUBMITTED,
        user.id,
        "Soumission de la demande d'exonération",
      );

      return created;
    } catch (error) {
      if (error instanceof BadRequestException) {
        throw error;
      }
      throw new UnprocessableEntityException(
        "Erreur lors de la création de la demande d'exonération.",
      );
    }
  }

  async findAll(user: User, params: ExonerationRequestSearchDto) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour consulter les demandes d'exonération.",
      );
    }

    try {
      const where: Prisma.ExonerationRequestWhereInput = {};

      if (params.search) {
        where.OR = [
          { dossierNumber: { contains: params.search, mode: 'insensitive' } },
          {
            applicantFirstName: { contains: params.search, mode: 'insensitive' },
          },
          { applicantLastName: { contains: params.search, mode: 'insensitive' } },
          { applicantEmail: { contains: params.search, mode: 'insensitive' } },
          { exonerationNumber: { contains: params.search, mode: 'insensitive' } },
        ];
      }

      if (
        params.status &&
        Object.values(ExonerationWorkflowStatus).includes(params.status)
      ) {
        where.currentStatus = params.status;
      }

      if (params.titleType) {
        where.titleType = {
          contains: params.titleType,
          mode: 'insensitive',
        };
      }

      if (params.fromDate || params.toDate) {
        where.createdAt = {};
        if (params.fromDate) {
          where.createdAt.gte = this.parseDateInput(params.fromDate);
        }
        if (params.toDate) {
          where.createdAt.lte = this.parseDateInput(params.toDate);
        }
      }

      if (!this.canManage(user)) {
        where.createdBy = user.id;
      }

      const paginationOptions: Prisma.ExonerationRequestFindManyArgs = {};
      if (params.page !== undefined && params.limit !== undefined) {
        paginationOptions.skip = (params.page - 1) * params.limit;
        paginationOptions.take = params.limit;
      }

      const [rows, total] = await Promise.all([
        this.prisma.exonerationRequest.findMany({
          where,
          include: {
            histories: {
              orderBy: { createdAt: 'desc' },
              take: 20,
            },
          },
          orderBy: { createdAt: 'desc' },
          ...paginationOptions,
        }),
        this.prisma.exonerationRequest.count({ where }),
      ]);

      return {
        ...new PaginationMeta(params.page || 1, params.limit || rows.length, total),
        data: rows,
      };
    } catch (error) {
      if (error instanceof BadRequestException) {
        throw error;
      }
      throw new UnprocessableEntityException(
        "Erreur lors de la récupération des demandes d'exonération.",
      );
    }
  }

  async findOne(id: string, user: User) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour consulter cette demande.",
      );
    }

    const item = await this.prisma.exonerationRequest.findUnique({
      where: { id },
      include: {
        histories: {
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!item) {
      throw new NotFoundException("Demande d'exonération introuvable.");
    }

    if (!this.canManage(user) && item.createdBy !== user.id) {
      throw new NotFoundException("Demande d'exonération introuvable.");
    }

    return item;
  }

  async update(id: string, dto: UpdateExonerationRequestDto, user: User) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour modifier cette demande.",
      );
    }

    const existing = await this.ensureExists(id);
    const canEdit =
      this.canManage(user) ||
      (existing.createdBy === user.id &&
        [ExonerationWorkflowStatus.SUBMITTED, ExonerationWorkflowStatus.REJECTED].includes(
          existing.currentStatus,
        ));

    if (!canEdit) {
      throw new BadRequestException(
        'Modification non autorisée pour ce statut de dossier.',
      );
    }

    try {
      return await this.prisma.exonerationRequest.update({
        where: { id },
        data: {
          applicantFirstName: dto.applicantFirstName?.trim(),
          applicantLastName: dto.applicantLastName?.trim(),
          applicantEmail: dto.applicantEmail?.trim(),
          applicantPhone: dto.applicantPhone?.trim(),
          organization: dto.organization?.trim(),
          titleType: dto.titleType?.trim(),
          requestReason: dto.requestReason?.trim(),
          supportingDocuments: dto.supportingDocuments?.trim(),
        },
      });
    } catch {
      throw new UnprocessableEntityException(
        "Erreur lors de la mise à jour de la demande d'exonération.",
      );
    }
  }

  async verify(id: string, dto: VerifyExonerationRequestDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour vérifier un dossier.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== ExonerationWorkflowStatus.SUBMITTED) {
      throw new BadRequestException(
        'La vérification automatique est possible uniquement après soumission.',
      );
    }

    const automaticScore = dto.automaticScore ?? 100;
    const updated = await this.prisma.exonerationRequest.update({
      where: { id },
      data: {
        automaticVerification: { score: automaticScore },
        currentStatus: ExonerationWorkflowStatus.AUTO_VERIFIED,
      },
    });

    await this.createHistory(
      id,
      ExonerationWorkflowStatus.AUTO_VERIFIED,
      user.id,
      dto.notes?.trim() || 'Vérification automatique exécutée',
      {
        automaticScore,
      },
    );

    return updated;
  }

  async validateDpct(id: string, dto: ValidateDpctExonerationRequestDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour la validation DPCT.",
      );
    }

    const existing = await this.ensureExists(id);
    if (
      ![
        ExonerationWorkflowStatus.SUBMITTED,
        ExonerationWorkflowStatus.AUTO_VERIFIED,
      ].includes(existing.currentStatus)
    ) {
      throw new BadRequestException(
        'Validation DPCT impossible pour ce statut de dossier.',
      );
    }

    const approved = dto.decision === ExonerationValidationDecision.APPROVE;
    const nextStatus = approved
      ? ExonerationWorkflowStatus.DPCT_VALIDATED
      : ExonerationWorkflowStatus.REJECTED;

    const updated = await this.prisma.exonerationRequest.update({
      where: { id },
      data: {
        dpctDecision: dto.decision,
        dpctNotes: dto.notes?.trim(),
        currentStatus: nextStatus,
        rejectionReason: approved ? null : dto.rejectionReason?.trim(),
        dpctValidatedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      nextStatus,
      user.id,
      approved ? 'Validation DPCT approuvée' : 'Validation DPCT rejetée',
      {
        decision: dto.decision,
        rejectionReason: dto.rejectionReason?.trim() || null,
      },
    );

    return updated;
  }

  async validateDouane(id: string, dto: ValidateCustomsExonerationRequestDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour la validation Douane.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== ExonerationWorkflowStatus.DPCT_VALIDATED) {
      throw new BadRequestException(
        'Validation Douane possible uniquement après validation DPCT.',
      );
    }

    const approved = dto.decision === ExonerationValidationDecision.APPROVE;
    const nextStatus = approved
      ? ExonerationWorkflowStatus.CUSTOMS_VALIDATED
      : ExonerationWorkflowStatus.REJECTED;

    const updated = await this.prisma.exonerationRequest.update({
      where: { id },
      data: {
        customsDecision: dto.decision,
        customsNotes: dto.notes?.trim(),
        currentStatus: nextStatus,
        rejectionReason: approved ? null : dto.rejectionReason?.trim(),
        customsValidatedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      nextStatus,
      user.id,
      approved ? 'Validation Douane approuvée' : 'Validation Douane rejetée',
      {
        decision: dto.decision,
        rejectionReason: dto.rejectionReason?.trim() || null,
      },
    );

    return updated;
  }

  async notifyRejection(id: string, dto: NotifyRejectionExonerationRequestDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour notifier un rejet.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== ExonerationWorkflowStatus.REJECTED) {
      throw new BadRequestException(
        "Seuls les dossiers rejetés peuvent être notifiés.",
      );
    }

    const updated = await this.prisma.exonerationRequest.update({
      where: { id },
      data: {
        currentStatus: ExonerationWorkflowStatus.NOTIFIED,
        notifiedAt: new Date(),
        notifiedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      ExonerationWorkflowStatus.NOTIFIED,
      user.id,
      dto.notes?.trim() || 'Notification de rejet envoyée',
      undefined,
    );

    return updated;
  }

  async emit(id: string, dto: EmitExonerationDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour émettre un TE.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== ExonerationWorkflowStatus.CUSTOMS_VALIDATED) {
      throw new BadRequestException(
        "L'émission est possible uniquement après validation Douane.",
      );
    }

    const exonerationNumber =
      dto.exonerationNumber?.trim() || (await this.generateExonerationNumber());
    const issuedAt = this.parseDateInput(dto.issuedAt) || new Date();
    const expiryDate = this.parseDateInput(dto.expiryDate) || existing.expiryDate;

    const updated = await this.prisma.exonerationRequest.update({
      where: { id },
      data: {
        exonerationNumber,
        issuedAt,
        expiryDate,
        customsNotes: dto.notes?.trim() ?? existing.customsNotes,
        currentStatus: ExonerationWorkflowStatus.ISSUED,
        issuedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      ExonerationWorkflowStatus.ISSUED,
      user.id,
      dto.notes?.trim() || "Titre d'exonération émis",
      {
        exonerationNumber,
        issuedAt: issuedAt.toISOString(),
      },
    );

    return updated;
  }

  async markNotified(id: string, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour clôturer un dossier.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== ExonerationWorkflowStatus.ISSUED) {
      throw new BadRequestException(
        'Seuls les dossiers émis peuvent être notifiés.',
      );
    }

    const updated = await this.prisma.exonerationRequest.update({
      where: { id },
      data: {
        currentStatus: ExonerationWorkflowStatus.NOTIFIED,
        notifiedAt: new Date(),
        notifiedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      ExonerationWorkflowStatus.NOTIFIED,
      user.id,
      'Dossier notifié',
    );

    return updated;
  }

  async getHistory(id: string, user: User) {
    const existing = await this.ensureExists(id);
    if (!this.canManage(user) && existing.createdBy !== user.id) {
      throw new NotFoundException("Demande d'exonération introuvable.");
    }

    return this.prisma.exonerationStatusHistory.findMany({
      where: { exonerationRequestId: id },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getKpis(user: User, params: ExonerationKpiFiltersDto) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour consulter les KPI.",
      );
    }

    const where: Prisma.ExonerationRequestWhereInput = {};
    if (params.fromDate || params.toDate) {
      where.createdAt = {};
      if (params.fromDate) {
        where.createdAt.gte = this.parseDateInput(params.fromDate);
      }
      if (params.toDate) {
        where.createdAt.lte = this.parseDateInput(params.toDate);
      }
    }

    if (!this.canManage(user)) {
      where.createdBy = user.id;
    }

    const [
      total,
      submitted,
      autoVerified,
      dpctValidated,
      customsValidated,
      rejected,
      issued,
      notified,
      avgDurationAgg,
    ] = await Promise.all([
      this.prisma.exonerationRequest.count({ where }),
      this.prisma.exonerationRequest.count({
        where: { ...where, currentStatus: ExonerationWorkflowStatus.SUBMITTED },
      }),
      this.prisma.exonerationRequest.count({
        where: { ...where, currentStatus: ExonerationWorkflowStatus.AUTO_VERIFIED },
      }),
      this.prisma.exonerationRequest.count({
        where: { ...where, currentStatus: ExonerationWorkflowStatus.DPCT_VALIDATED },
      }),
      this.prisma.exonerationRequest.count({
        where: {
          ...where,
          currentStatus: ExonerationWorkflowStatus.CUSTOMS_VALIDATED,
        },
      }),
      this.prisma.exonerationRequest.count({
        where: { ...where, currentStatus: ExonerationWorkflowStatus.REJECTED },
      }),
      this.prisma.exonerationRequest.count({
        where: { ...where, currentStatus: ExonerationWorkflowStatus.ISSUED },
      }),
      this.prisma.exonerationRequest.count({
        where: { ...where, currentStatus: ExonerationWorkflowStatus.NOTIFIED },
      }),
      this.prisma.exonerationRequest.aggregate({
        where: { ...where, issuedAt: { not: null } },
        _avg: { processingDurationHours: true },
      }),
    ]);

    const rejectionRate = total > 0 ? Number(((rejected / total) * 100).toFixed(2)) : 0;

    return {
      total,
      submitted,
      autoVerified,
      dpctValidated,
      customsValidated,
      rejected,
      issued,
      notified,
      rejectionRate,
      avgProcessingHours: Number(
        Number(avgDurationAgg._avg.processingDurationHours || 0).toFixed(2),
      ),
    };
  }

}
