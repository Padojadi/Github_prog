import { Module } from '@nestjs/common';
import { PrismaModule } from 'src/config/prisma/prisma.module';
import { ExonerationController } from './exoneration.controller';
import { ExonerationService } from './exoneration.service';

@Module({
  imports: [PrismaModule],
  controllers: [ExonerationController],
  providers: [ExonerationService],
})
export class ExonerationModule {}
