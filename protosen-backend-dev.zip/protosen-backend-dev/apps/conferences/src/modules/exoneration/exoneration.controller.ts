import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  ValidationPipe,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { UserPermission } from 'src/constants/enum';
import { Roles } from 'src/core/decorators/roles.decorator';
import { ExonerationService } from './exoneration.service';
import {
  CreateExonerationRequestDto,
  EmitExonerationDto,
  ExonerationKpiFiltersDto,
  ExonerationRequestSearchDto,
  NotifyRejectionExonerationRequestDto,
  ValidateCustomsExonerationRequestDto,
  ValidateDpctExonerationRequestDto,
  VerifyExonerationRequestDto,
} from './dto/create-exoneration-request.dto';
import { UpdateExonerationRequestDto } from './dto/update-exoneration-request.dto';

@ApiTags('exoneration')
@Controller('exoneration')
export class ExonerationController {
  constructor(private readonly exonerationService: ExonerationService) {}

  @Get()
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  findAll(
    @Req() req,
    @Query(new ValidationPipe({ transform: true, skipMissingProperties: true }))
    dto: ExonerationRequestSearchDto,
  ) {
    return this.exonerationService.findAll(req.user, dto);
  }

  @Post()
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  create(@Req() req, @Body() dto: CreateExonerationRequestDto) {
    return this.exonerationService.create(req.user, dto);
  }

  @Get(':id')
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  findOne(@Param('id') id: string, @Req() req) {
    return this.exonerationService.findOne(id, req.user);
  }

  @Patch(':id')
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  update(@Param('id') id: string, @Req() req, @Body() dto: UpdateExonerationRequestDto) {
    return this.exonerationService.update(id, dto, req.user);
  }

  @Patch(':id/verify')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  verify(
    @Param('id') id: string,
    @Req() req,
    @Body() dto: VerifyExonerationRequestDto,
  ) {
    return this.exonerationService.verify(id, dto, req.user);
  }

  @Patch(':id/validate-dpct')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  validateDpct(
    @Param('id') id: string,
    @Req() req,
    @Body() dto: ValidateDpctExonerationRequestDto,
  ) {
    return this.exonerationService.validateDpct(id, dto, req.user);
  }

  @Patch(':id/validate-douane')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  validateDouane(
    @Param('id') id: string,
    @Req() req,
    @Body() dto: ValidateCustomsExonerationRequestDto,
  ) {
    return this.exonerationService.validateDouane(id, dto, req.user);
  }

  @Patch(':id/notify-rejection')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  notifyRejection(
    @Param('id') id: string,
    @Req() req,
    @Body() dto: NotifyRejectionExonerationRequestDto,
  ) {
    return this.exonerationService.notifyRejection(id, dto, req.user);
  }

  @Patch(':id/emit')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  emit(@Param('id') id: string, @Req() req, @Body() dto: EmitExonerationDto) {
    return this.exonerationService.emit(id, dto, req.user);
  }

  @Patch(':id/mark-notified')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  markNotified(@Param('id') id: string, @Req() req) {
    return this.exonerationService.markNotified(id, req.user);
  }

  @Get(':id/history')
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  getHistory(@Param('id') id: string, @Req() req) {
    return this.exonerationService.getHistory(id, req.user);
  }

  @Get('kpis/summary')
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  getKpis(
    @Req() req,
    @Query(new ValidationPipe({ transform: true, skipMissingProperties: true }))
    dto: ExonerationKpiFiltersDto,
  ) {
    return this.exonerationService.getKpis(req.user, dto);
  }
}
