import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsDate,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  Min,
} from 'class-validator';
import {
  ExonerationValidationDecision,
  ExonerationWorkflowStatus,
} from '@prisma/client';
import { SearchDto } from 'src/core/dtos/search.dto';

export class CreateExonerationRequestDto {
  @ApiProperty({ description: 'Prénom du demandeur' })
  @IsString()
  applicantFirstName: string;

  @ApiProperty({ description: 'Nom du demandeur' })
  @IsString()
  applicantLastName: string;

  @ApiProperty({ description: 'Email du demandeur' })
  @IsString()
  applicantEmail: string;

  @ApiPropertyOptional({ description: 'Téléphone du demandeur' })
  @IsOptional()
  @IsString()
  applicantPhone?: string;

  @ApiPropertyOptional({ description: 'Organisation du demandeur' })
  @IsOptional()
  @IsString()
  organization?: string;

  @ApiProperty({ description: "Type de titre d'exonération demandé" })
  @IsString()
  titleType: string;

  @ApiProperty({ description: 'Motif de la demande' })
  @IsString()
  requestReason: string;

  @ApiProperty({
    description: 'Pièces justificatives (texte, références ou JSON stringifié)',
  })
  @IsString()
  supportingDocuments: string;
}

export class ExonerationRequestSearchDto extends SearchDto {
  @ApiPropertyOptional({
    description: 'Filtrer par statut',
    enum: ExonerationWorkflowStatus,
  })
  @IsOptional()
  @IsEnum(ExonerationWorkflowStatus)
  status?: ExonerationWorkflowStatus;

  @ApiPropertyOptional({
    description: "Filtrer par type de titre d'exonération",
  })
  @IsOptional()
  @IsString()
  titleType?: string;

  @ApiPropertyOptional({
    description: 'Date de début',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  fromDate?: Date;

  @ApiPropertyOptional({
    description: 'Date de fin',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  toDate?: Date;
}

export class VerifyExonerationRequestDto {
  @ApiPropertyOptional({ description: 'Score de vérification automatique' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  automaticScore?: number;

  @ApiPropertyOptional({ description: 'Notes de vérification' })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class ValidateDpctExonerationRequestDto {
  @ApiProperty({ enum: ExonerationValidationDecision })
  @IsEnum(ExonerationValidationDecision)
  decision: ExonerationValidationDecision;

  @ApiPropertyOptional({ description: 'Observations DPCT' })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({ description: 'Motif du rejet DPCT' })
  @IsOptional()
  @IsString()
  rejectionReason?: string;
}

export class ValidateCustomsExonerationRequestDto {
  @ApiProperty({ enum: ExonerationValidationDecision })
  @IsEnum(ExonerationValidationDecision)
  decision: ExonerationValidationDecision;

  @ApiPropertyOptional({ description: 'Observations Douane' })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({ description: 'Motif du rejet Douane' })
  @IsOptional()
  @IsString()
  rejectionReason?: string;
}

export class NotifyRejectionExonerationRequestDto {
  @ApiProperty({
    description: 'Canaux de notification utilisés',
    type: [String],
    example: ['EMAIL', 'SMS'],
  })
  @IsArray()
  @ArrayNotEmpty()
  @IsString({ each: true })
  channels: string[];

  @ApiPropertyOptional({ description: 'Message/notes de notification' })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class EmitExonerationDto {
  @ApiPropertyOptional({ description: "Numéro du titre d'exonération" })
  @IsOptional()
  @IsString()
  exonerationNumber?: string;

  @ApiPropertyOptional({
    description: "Date d'émission",
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  issuedAt?: Date;

  @ApiPropertyOptional({
    description: "Date d'expiration",
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  expiryDate?: Date;

  @ApiPropertyOptional({ description: "Notes d'émission" })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class ExonerationKpiFiltersDto {
  @ApiPropertyOptional({
    description: 'Date de début pour les KPI',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  fromDate?: Date;

  @ApiPropertyOptional({
    description: 'Date de fin pour les KPI',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  toDate?: Date;
}
