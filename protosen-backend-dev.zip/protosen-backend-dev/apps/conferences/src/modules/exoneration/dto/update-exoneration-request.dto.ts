import { PartialType } from '@nestjs/swagger';
import { CreateExonerationRequestDto } from './create-exoneration-request.dto';

export class UpdateExonerationRequestDto extends PartialType(
  CreateExonerationRequestDto,
) {}

