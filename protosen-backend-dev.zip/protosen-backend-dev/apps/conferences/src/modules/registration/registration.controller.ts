import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  ValidationPipe,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { UserPermission } from 'src/constants/enum';
import { Roles } from 'src/core/decorators/roles.decorator';
import { RegistrationService } from './registration.service';
import {
  AssignRegistrationRequestDto,
  CreateRegistrationRequestDto,
  NotifyRegistrationRequestDto,
  RegistrationKpiFiltersDto,
  RegistrationRequestSearchDto,
  ValidateRegistrationRequestDto,
  VerifyRegistrationRequestDto,
} from './dto/create-registration-request.dto';
import { UpdateRegistrationRequestDto } from './dto/update-registration-request.dto';

@ApiTags('registration')
@Controller('registration')
export class RegistrationController {
  constructor(private readonly registrationService: RegistrationService) {}

  @Get()
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  findAll(
    @Req() req,
    @Query(new ValidationPipe({ transform: true, skipMissingProperties: true }))
    dto: RegistrationRequestSearchDto,
  ) {
    return this.registrationService.findAll(req.user, dto);
  }

  @Post()
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  create(@Req() req, @Body() dto: CreateRegistrationRequestDto) {
    return this.registrationService.create(req.user, dto);
  }

  @Get(':id')
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  findOne(@Param('id') id: string, @Req() req) {
    return this.registrationService.findOne(id, req.user);
  }

  @Patch(':id')
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  update(@Param('id') id: string, @Req() req, @Body() dto: UpdateRegistrationRequestDto) {
    return this.registrationService.update(id, dto, req.user);
  }

  @Patch(':id/verify')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  verify(
    @Param('id') id: string,
    @Req() req,
    @Body() dto: VerifyRegistrationRequestDto,
  ) {
    return this.registrationService.verify(id, dto, req.user);
  }

  @Patch(':id/validate-agent')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  validateAgent(
    @Param('id') id: string,
    @Req() req,
    @Body() dto: ValidateRegistrationRequestDto,
  ) {
    return this.registrationService.validateAgent(id, dto, req.user);
  }

  @Patch(':id/assign')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  assign(
    @Param('id') id: string,
    @Req() req,
    @Body() dto: AssignRegistrationRequestDto,
  ) {
    return this.registrationService.assign(id, dto, req.user);
  }

  @Patch(':id/notify')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  notify(
    @Param('id') id: string,
    @Req() req,
    @Body() dto: NotifyRegistrationRequestDto,
  ) {
    return this.registrationService.notify(id, dto, req.user);
  }

  @Patch(':id/withdraw')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  withdraw(@Param('id') id: string, @Req() req) {
    return this.registrationService.withdraw(id, req.user);
  }

  @Patch(':id/archive')
  @Roles(UserPermission.MANAGE_CONFERENCES, UserPermission.ACCESS_CONFERENCE_MODULE)
  archive(@Param('id') id: string, @Req() req) {
    return this.registrationService.archive(id, req.user);
  }

  @Get(':id/history')
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  getHistory(@Param('id') id: string, @Req() req) {
    return this.registrationService.getHistory(id, req.user);
  }

  @Get('kpis/summary')
  @Roles(UserPermission.ACCESS_CONFERENCE_MODULE)
  getKpis(
    @Req() req,
    @Query(new ValidationPipe({ transform: true, skipMissingProperties: true }))
    dto: RegistrationKpiFiltersDto,
  ) {
    return this.registrationService.getKpis(req.user, dto);
  }
}
