import {
  BadRequestException,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import {
  Prisma,
  RegistrationValidationDecision,
  RegistrationWorkflowStatus,
} from '@prisma/client';
import { PrismaService } from 'src/config/prisma/prisma.service';
import { PaginationMeta } from 'src/core/dtos/paginationmeta';
import { User } from '../user/generated/user';
import {
  AssignRegistrationRequestDto,
  CreateRegistrationRequestDto,
  NotifyRegistrationRequestDto,
  RegistrationKpiFiltersDto,
  RegistrationRequestSearchDto,
  ValidateRegistrationRequestDto,
  VerifyRegistrationRequestDto,
} from './dto/create-registration-request.dto';
import { UpdateRegistrationRequestDto } from './dto/update-registration-request.dto';

@Injectable()
export class RegistrationService {
  constructor(private readonly prisma: PrismaService) {}

  private hasPermission(user: User, permission: string): boolean {
    return (user?.accessGroup?.permissions || []).includes(permission);
  }

  private canAccess(user: User): boolean {
    return (
      this.hasPermission(user, 'ACCESS_CONFERENCE_MODULE') ||
      user?.role === 'admin' ||
      user?.role === 'super_admin'
    );
  }

  private canManage(user: User): boolean {
    return (
      this.hasPermission(user, 'MANAGE_CONFERENCES') ||
      user?.role === 'admin' ||
      user?.role === 'super_admin'
    );
  }

  private parseDateInput(value?: string | Date) {
    if (!value) {
      return undefined;
    }
    const parsed = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(parsed.getTime())) {
      throw new BadRequestException('Format de date invalide.');
    }
    return parsed;
  }

  private async generateDossierNumber() {
    const year = new Date().getFullYear();
    const prefix = `IMM-${year}-`;
    const count = await this.prisma.registrationRequest.count({
      where: { dossierNumber: { startsWith: prefix } },
    });
    return `${prefix}${String(count + 1).padStart(5, '0')}`;
  }

  private async generateAssignmentNumber() {
    const year = new Date().getFullYear();
    const prefix = `ATR-${year}-`;
    const count = await this.prisma.registrationRequest.count({
      where: { assignmentNumber: { startsWith: prefix } },
    });
    return `${prefix}${String(count + 1).padStart(5, '0')}`;
  }

  private async createHistory(
    registrationRequestId: string,
    status: RegistrationWorkflowStatus,
    changedBy: string,
    notes?: string,
    metadata?: Prisma.InputJsonValue,
  ) {
    await this.prisma.registrationStatusHistory.create({
      data: {
        registrationRequestId,
        status,
        changedBy,
        notes,
        metadata,
      },
    });
  }

  private async ensureExists(id: string) {
    const existing = await this.prisma.registrationRequest.findUnique({
      where: { id },
    });
    if (!existing) {
      throw new NotFoundException("Demande d'immatriculation introuvable.");
    }
    return existing;
  }

  async create(user: User, dto: CreateRegistrationRequestDto) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour créer une demande d'immatriculation.",
      );
    }

    try {
      const dossierNumber = await this.generateDossierNumber();
      const created = await this.prisma.registrationRequest.create({
        data: {
          dossierNumber,
          formType: dto.formType,
          applicantFirstName: dto.applicantFirstName.trim(),
          applicantLastName: dto.applicantLastName.trim(),
          applicantEmail: dto.applicantEmail.trim(),
          applicantPhone: dto.applicantPhone?.trim(),
          organization: dto.organization?.trim(),
          subject: dto.subject.trim(),
          vehicleInfo: dto.vehicleInfo ? (dto.vehicleInfo as Prisma.InputJsonValue) : undefined,
          supportingDocuments: dto.supportingDocuments.trim(),
          createdBy: user.id,
          currentStatus: RegistrationWorkflowStatus.SUBMITTED,
        },
      });

      await this.createHistory(
        created.id,
        RegistrationWorkflowStatus.SUBMITTED,
        user.id,
        "Soumission de la demande d'immatriculation",
      );

      return created;
    } catch (error) {
      if (error instanceof BadRequestException) {
        throw error;
      }
      throw new UnprocessableEntityException(
        "Erreur lors de la création de la demande d'immatriculation.",
      );
    }
  }

  async findAll(user: User, params: RegistrationRequestSearchDto) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour consulter les demandes d'immatriculation.",
      );
    }

    try {
      const where: Prisma.RegistrationRequestWhereInput = {};

      if (params.search) {
        where.OR = [
          { dossierNumber: { contains: params.search, mode: 'insensitive' } },
          { applicantFirstName: { contains: params.search, mode: 'insensitive' } },
          { applicantLastName: { contains: params.search, mode: 'insensitive' } },
          { applicantEmail: { contains: params.search, mode: 'insensitive' } },
          { assignmentNumber: { contains: params.search, mode: 'insensitive' } },
          { permitNumber: { contains: params.search, mode: 'insensitive' } },
        ];
      }

      if (
        params.status &&
        Object.values(RegistrationWorkflowStatus).includes(params.status)
      ) {
        where.currentStatus = params.status;
      }

      if (params.formType) {
        where.formType = params.formType;
      }

      if (params.fromDate || params.toDate) {
        where.createdAt = {};
        if (params.fromDate) {
          where.createdAt.gte = this.parseDateInput(params.fromDate);
        }
        if (params.toDate) {
          where.createdAt.lte = this.parseDateInput(params.toDate);
        }
      }

      if (!this.canManage(user)) {
        where.createdBy = user.id;
      }

      const paginationOptions: Prisma.RegistrationRequestFindManyArgs = {};
      if (params.page !== undefined && params.limit !== undefined) {
        paginationOptions.skip = (params.page - 1) * params.limit;
        paginationOptions.take = params.limit;
      }

      const [rows, total] = await Promise.all([
        this.prisma.registrationRequest.findMany({
          where,
          include: {
            histories: {
              orderBy: { createdAt: 'desc' },
              take: 20,
            },
          },
          orderBy: { createdAt: 'desc' },
          ...paginationOptions,
        }),
        this.prisma.registrationRequest.count({ where }),
      ]);

      return {
        ...new PaginationMeta(params.page || 1, params.limit || rows.length, total),
        data: rows,
      };
    } catch (error) {
      if (error instanceof BadRequestException) {
        throw error;
      }
      throw new UnprocessableEntityException(
        "Erreur lors de la récupération des demandes d'immatriculation.",
      );
    }
  }

  async findOne(id: string, user: User) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour consulter cette demande.",
      );
    }

    const item = await this.prisma.registrationRequest.findUnique({
      where: { id },
      include: {
        histories: {
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!item) {
      throw new NotFoundException("Demande d'immatriculation introuvable.");
    }

    if (!this.canManage(user) && item.createdBy !== user.id) {
      throw new NotFoundException("Demande d'immatriculation introuvable.");
    }

    return item;
  }

  async update(id: string, dto: UpdateRegistrationRequestDto, user: User) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour modifier cette demande.",
      );
    }

    const existing = await this.ensureExists(id);
    const canEdit =
      this.canManage(user) ||
      (existing.createdBy === user.id &&
        (existing.currentStatus === RegistrationWorkflowStatus.SUBMITTED ||
          existing.currentStatus === RegistrationWorkflowStatus.REJECTED));

    if (!canEdit) {
      throw new BadRequestException(
        'Modification non autorisée pour ce statut de dossier.',
      );
    }

    try {
      return await this.prisma.registrationRequest.update({
        where: { id },
        data: {
          formType: dto.formType,
          applicantFirstName: dto.applicantFirstName?.trim(),
          applicantLastName: dto.applicantLastName?.trim(),
          applicantEmail: dto.applicantEmail?.trim(),
          applicantPhone: dto.applicantPhone?.trim(),
          organization: dto.organization?.trim(),
          subject: dto.subject?.trim(),
          supportingDocuments: dto.supportingDocuments?.trim(),
          vehicleInfo: dto.vehicleInfo as Prisma.InputJsonValue | undefined,
          correctionNotes: dto.correctionNotes?.trim(),
        },
      });
    } catch {
      throw new UnprocessableEntityException(
        "Erreur lors de la mise à jour de la demande d'immatriculation.",
      );
    }
  }

  async verify(id: string, dto: VerifyRegistrationRequestDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour vérifier un dossier.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== RegistrationWorkflowStatus.SUBMITTED) {
      throw new BadRequestException(
        'La vérification automatique est possible uniquement après soumission.',
      );
    }

    const automaticScore = dto.automaticScore ?? 100;
    const updated = await this.prisma.registrationRequest.update({
      where: { id },
      data: {
        automaticVerification: { score: automaticScore },
        currentStatus: RegistrationWorkflowStatus.AUTO_VERIFIED,
      },
    });

    await this.createHistory(
      id,
      RegistrationWorkflowStatus.AUTO_VERIFIED,
      user.id,
      dto.notes?.trim() || 'Vérification automatique exécutée',
      {
        automaticScore,
      },
    );

    return updated;
  }

  async validateAgent(id: string, dto: ValidateRegistrationRequestDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour la validation agent.",
      );
    }

    const existing = await this.ensureExists(id);
    if (
      existing.currentStatus !== RegistrationWorkflowStatus.SUBMITTED &&
      existing.currentStatus !== RegistrationWorkflowStatus.AUTO_VERIFIED
    ) {
      throw new BadRequestException(
        'Validation impossible pour ce statut de dossier.',
      );
    }

    const approved = dto.decision === RegistrationValidationDecision.APPROVE;
    const nextStatus = approved
      ? RegistrationWorkflowStatus.AGENT_VALIDATED
      : RegistrationWorkflowStatus.REJECTED;

    const updated = await this.prisma.registrationRequest.update({
      where: { id },
      data: {
        agentDecision: dto.decision,
        agentNotes: dto.notes?.trim(),
        rejectionReason: approved ? null : dto.rejectionReason?.trim(),
        currentStatus: nextStatus,
        validatedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      nextStatus,
      user.id,
      approved ? 'Validation agent approuvée' : 'Validation agent rejetée',
      {
        decision: dto.decision,
        rejectionReason: dto.rejectionReason?.trim() || null,
      },
    );

    return updated;
  }

  async assign(id: string, dto: AssignRegistrationRequestDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour attribuer un dossier.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== RegistrationWorkflowStatus.AGENT_VALIDATED) {
      throw new BadRequestException(
        "L'attribution est possible uniquement après validation agent.",
      );
    }

    const assignmentNumber =
      dto.assignmentNumber?.trim() || (await this.generateAssignmentNumber());
    const assignedAt = new Date();

    const updated = await this.prisma.registrationRequest.update({
      where: { id },
      data: {
        assignmentNumber,
        permitNumber: dto.permitNumber?.trim(),
        assignedAt,
        currentStatus: RegistrationWorkflowStatus.ASSIGNED,
        assignedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      RegistrationWorkflowStatus.ASSIGNED,
      user.id,
      dto.notes?.trim() || 'Dossier attribué',
      {
        assignmentNumber,
        permitNumber: dto.permitNumber?.trim() || null,
      },
    );

    return updated;
  }

  async notify(id: string, dto: NotifyRegistrationRequestDto, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour notifier un dossier.",
      );
    }

    const existing = await this.ensureExists(id);
    if (
      existing.currentStatus !== RegistrationWorkflowStatus.ASSIGNED &&
      existing.currentStatus !== RegistrationWorkflowStatus.REJECTED
    ) {
      throw new BadRequestException(
        'Notification impossible pour ce statut de dossier.',
      );
    }

    const updated = await this.prisma.registrationRequest.update({
      where: { id },
      data: {
        currentStatus: RegistrationWorkflowStatus.NOTIFIED,
        notifiedAt: new Date(),
        notifiedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      RegistrationWorkflowStatus.NOTIFIED,
      user.id,
      dto.notes?.trim() || 'Notification envoyée',
      {
        channels: dto.channels,
      },
    );

    return updated;
  }

  async withdraw(id: string, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour marquer le retrait.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== RegistrationWorkflowStatus.NOTIFIED) {
      throw new BadRequestException(
        'Seuls les dossiers notifiés peuvent être retirés.',
      );
    }

    const updated = await this.prisma.registrationRequest.update({
      where: { id },
      data: {
        currentStatus: RegistrationWorkflowStatus.WITHDRAWN,
        withdrawnAt: new Date(),
        withdrawnBy: user.id,
      },
    });

    await this.createHistory(
      id,
      RegistrationWorkflowStatus.WITHDRAWN,
      user.id,
      'Retrait électronique sécurisé enregistré',
    );

    return updated;
  }

  async archive(id: string, user: User) {
    if (!this.canManage(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour archiver un dossier.",
      );
    }

    const existing = await this.ensureExists(id);
    if (existing.currentStatus !== RegistrationWorkflowStatus.WITHDRAWN) {
      throw new BadRequestException(
        'Seuls les dossiers retirés peuvent être archivés.',
      );
    }

    const updated = await this.prisma.registrationRequest.update({
      where: { id },
      data: {
        currentStatus: RegistrationWorkflowStatus.ARCHIVED,
        archivedAt: new Date(),
        archivedBy: user.id,
      },
    });

    await this.createHistory(
      id,
      RegistrationWorkflowStatus.ARCHIVED,
      user.id,
      'Dossier archivé',
    );

    return updated;
  }

  async getHistory(id: string, user: User) {
    const existing = await this.ensureExists(id);
    if (!this.canManage(user) && existing.createdBy !== user.id) {
      throw new NotFoundException("Demande d'immatriculation introuvable.");
    }

    return this.prisma.registrationStatusHistory.findMany({
      where: { registrationRequestId: id },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getKpis(user: User, params: RegistrationKpiFiltersDto) {
    if (!this.canAccess(user)) {
      throw new BadRequestException(
        "Vous n'avez pas les permissions pour consulter les KPI.",
      );
    }

    const where: Prisma.RegistrationRequestWhereInput = {};
    if (params.fromDate || params.toDate) {
      where.createdAt = {};
      if (params.fromDate) {
        where.createdAt.gte = this.parseDateInput(params.fromDate);
      }
      if (params.toDate) {
        where.createdAt.lte = this.parseDateInput(params.toDate);
      }
    }

    if (!this.canManage(user)) {
      where.createdBy = user.id;
    }

    const [
      total,
      submitted,
      autoVerified,
      agentValidated,
      assigned,
      notified,
      withdrawn,
      archived,
      rejected,
      assignedRows,
    ] = await Promise.all([
      this.prisma.registrationRequest.count({ where }),
      this.prisma.registrationRequest.count({
        where: { ...where, currentStatus: RegistrationWorkflowStatus.SUBMITTED },
      }),
      this.prisma.registrationRequest.count({
        where: {
          ...where,
          currentStatus: RegistrationWorkflowStatus.AUTO_VERIFIED,
        },
      }),
      this.prisma.registrationRequest.count({
        where: {
          ...where,
          currentStatus: RegistrationWorkflowStatus.AGENT_VALIDATED,
        },
      }),
      this.prisma.registrationRequest.count({
        where: { ...where, currentStatus: RegistrationWorkflowStatus.ASSIGNED },
      }),
      this.prisma.registrationRequest.count({
        where: { ...where, currentStatus: RegistrationWorkflowStatus.NOTIFIED },
      }),
      this.prisma.registrationRequest.count({
        where: { ...where, currentStatus: RegistrationWorkflowStatus.WITHDRAWN },
      }),
      this.prisma.registrationRequest.count({
        where: { ...where, currentStatus: RegistrationWorkflowStatus.ARCHIVED },
      }),
      this.prisma.registrationRequest.count({
        where: { ...where, currentStatus: RegistrationWorkflowStatus.REJECTED },
      }),
      this.prisma.registrationRequest.findMany({
        where: { ...where, assignedAt: { not: null } },
        select: {
          createdAt: true,
          assignedAt: true,
        },
      }),
    ]);

    const rejectionRate = total > 0 ? Number(((rejected / total) * 100).toFixed(2)) : 0;
    const avgProcessingHours =
      assignedRows.length > 0
        ? Number(
            (
              assignedRows.reduce((acc, row) => {
                if (!row.assignedAt) {
                  return acc;
                }
                return acc + (row.assignedAt.getTime() - row.createdAt.getTime()) / (1000 * 60 * 60);
              }, 0) / assignedRows.length
            ).toFixed(2),
          )
        : 0;

    return {
      total,
      submitted,
      autoVerified,
      agentValidated,
      assigned,
      notified,
      withdrawn,
      archived,
      rejected,
      rejectionRate,
      avgProcessingHours,
    };
  }
}
