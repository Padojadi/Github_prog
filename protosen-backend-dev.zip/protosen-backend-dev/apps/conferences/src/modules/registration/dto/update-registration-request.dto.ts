import { PartialType } from '@nestjs/swagger';
import { CreateRegistrationRequestDto } from './create-registration-request.dto';
import { IsOptional, IsString } from 'class-validator';

export class UpdateRegistrationRequestDto extends PartialType(
  CreateRegistrationRequestDto,
) {
  @IsOptional()
  @IsString()
  correctionNotes?: string;
}
