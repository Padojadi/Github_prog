import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsDate,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  Min,
} from 'class-validator';
import {
  RegistrationFormType,
  RegistrationValidationDecision,
  RegistrationWorkflowStatus,
} from '@prisma/client';
import { SearchDto } from 'src/core/dtos/search.dto';

export class CreateRegistrationRequestDto {
  @ApiProperty({ enum: RegistrationFormType })
  @IsEnum(RegistrationFormType)
  formType: RegistrationFormType;

  @ApiProperty({ description: 'Prénom du demandeur' })
  @IsString()
  applicantFirstName: string;

  @ApiProperty({ description: 'Nom du demandeur' })
  @IsString()
  applicantLastName: string;

  @ApiProperty({ description: 'Email du demandeur' })
  @IsString()
  applicantEmail: string;

  @ApiPropertyOptional({ description: 'Téléphone du demandeur' })
  @IsOptional()
  @IsString()
  applicantPhone?: string;

  @ApiPropertyOptional({ description: 'Organisation du demandeur' })
  @IsOptional()
  @IsString()
  organization?: string;

  @ApiProperty({ description: "Objet de la demande d'immatriculation" })
  @IsString()
  subject: string;

  @ApiPropertyOptional({
    description: 'Informations véhicule (JSON sérialisé ou texte)',
  })
  @IsOptional()
  vehicleInfo?: unknown;

  @ApiProperty({
    description: 'Pièces justificatives (texte, références ou JSON stringifié)',
  })
  @IsString()
  supportingDocuments: string;
}

export class RegistrationRequestSearchDto extends SearchDto {
  @ApiPropertyOptional({ enum: RegistrationWorkflowStatus })
  @IsOptional()
  @IsEnum(RegistrationWorkflowStatus)
  status?: RegistrationWorkflowStatus;

  @ApiPropertyOptional({ enum: RegistrationFormType })
  @IsOptional()
  @IsEnum(RegistrationFormType)
  formType?: RegistrationFormType;

  @ApiPropertyOptional({
    description: 'Date de début',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  fromDate?: Date;

  @ApiPropertyOptional({
    description: 'Date de fin',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  toDate?: Date;
}

export class VerifyRegistrationRequestDto {
  @ApiPropertyOptional({ description: 'Score de vérification automatique' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  automaticScore?: number;

  @ApiPropertyOptional({ description: 'Notes de vérification' })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({
    description: 'Signaux DPI/contrôles automatiques détectés',
    type: [String],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  dpiFlags?: string[];
}

export class ValidateRegistrationRequestDto {
  @ApiProperty({ enum: RegistrationValidationDecision })
  @IsEnum(RegistrationValidationDecision)
  decision: RegistrationValidationDecision;

  @ApiPropertyOptional({ description: "Observations de validation de l'agent" })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({ description: 'Motif du rejet' })
  @IsOptional()
  @IsString()
  rejectionReason?: string;
}

export class AssignRegistrationRequestDto {
  @ApiPropertyOptional({ description: "Numéro d'attribution de l'immatriculation" })
  @IsOptional()
  @IsString()
  assignmentNumber?: string;

  @ApiPropertyOptional({ description: 'Numéro de permis' })
  @IsOptional()
  @IsString()
  permitNumber?: string;

  @ApiPropertyOptional({ description: "Observations d'attribution" })
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional({
    description: "Date d'attribution",
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  assignedAt?: Date;
}

export class NotifyRegistrationRequestDto {
  @ApiProperty({
    description: 'Canaux de notification utilisés',
    type: [String],
    example: ['EMAIL', 'SMS'],
  })
  @IsArray()
  @ArrayNotEmpty()
  @IsString({ each: true })
  channels: string[];

  @ApiPropertyOptional({ description: 'Message/notes de notification' })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class WithdrawRegistrationRequestDto {
  @ApiPropertyOptional({ description: 'Notes de retrait' })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class ArchiveRegistrationRequestDto {
  @ApiPropertyOptional({ description: "Notes d'archivage" })
  @IsOptional()
  @IsString()
  notes?: string;
}

export class CorrectRegistrationRequestDto {
  @ApiProperty({ description: 'Corrections apportées après rejet' })
  @IsString()
  correctionNotes: string;
}

export class RegistrationKpiFiltersDto {
  @ApiPropertyOptional({
    description: 'Date de début pour les KPI',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  fromDate?: Date;

  @ApiPropertyOptional({
    description: 'Date de fin pour les KPI',
    type: String,
    format: 'date-time',
  })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  toDate?: Date;
}
