-- CreateEnum
CREATE TYPE "RegistrationFormType" AS ENUM (
  'DEMANDE',
  'MUTATION',
  'PERMIS',
  'RETRAIT',
  'CORRECTION'
);

-- CreateEnum
CREATE TYPE "RegistrationWorkflowStatus" AS ENUM (
  'SUBMITTED',
  'AUTO_VERIFIED',
  'AGENT_VALIDATED',
  'ASSIGNED',
  'NOTIFIED',
  'WITHDRAWN',
  'ARCHIVED',
  'REJECTED'
);

-- CreateEnum
CREATE TYPE "RegistrationValidationDecision" AS ENUM (
  'APPROVE',
  'REJECT'
);

-- CreateTable
CREATE TABLE "RegistrationRequest" (
  "id" TEXT NOT NULL,
  "dossierNumber" TEXT NOT NULL,
  "formType" "RegistrationFormType" NOT NULL,
  "applicantFirstName" TEXT NOT NULL,
  "applicantLastName" TEXT NOT NULL,
  "applicantEmail" TEXT NOT NULL,
  "applicantPhone" TEXT,
  "organization" TEXT,
  "subject" TEXT NOT NULL,
  "vehicleInfo" JSONB,
  "supportingDocuments" TEXT NOT NULL,
  "currentStatus" "RegistrationWorkflowStatus" NOT NULL DEFAULT 'SUBMITTED',
  "automaticVerification" JSONB,
  "agentDecision" "RegistrationValidationDecision",
  "agentNotes" TEXT,
  "rejectionReason" TEXT,
  "correctionNotes" TEXT,
  "assignmentNumber" TEXT,
  "permitNumber" TEXT,
  "assignedAt" TIMESTAMP(3),
  "notifiedAt" TIMESTAMP(3),
  "withdrawnAt" TIMESTAMP(3),
  "archivedAt" TIMESTAMP(3),
  "createdBy" TEXT NOT NULL,
  "validatedBy" TEXT,
  "assignedBy" TEXT,
  "notifiedBy" TEXT,
  "withdrawnBy" TEXT,
  "archivedBy" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,

  CONSTRAINT "RegistrationRequest_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RegistrationStatusHistory" (
  "id" TEXT NOT NULL,
  "registrationRequestId" TEXT NOT NULL,
  "status" "RegistrationWorkflowStatus" NOT NULL,
  "changedBy" TEXT NOT NULL,
  "notes" TEXT,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "RegistrationStatusHistory_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "RegistrationRequest_dossierNumber_key" ON "RegistrationRequest"("dossierNumber");

-- CreateIndex
CREATE UNIQUE INDEX "RegistrationRequest_assignmentNumber_key" ON "RegistrationRequest"("assignmentNumber");

-- CreateIndex
CREATE INDEX "RegistrationRequest_currentStatus_idx" ON "RegistrationRequest"("currentStatus");

-- CreateIndex
CREATE INDEX "RegistrationRequest_createdBy_idx" ON "RegistrationRequest"("createdBy");

-- CreateIndex
CREATE INDEX "RegistrationRequest_applicantEmail_idx" ON "RegistrationRequest"("applicantEmail");

-- CreateIndex
CREATE INDEX "RegistrationRequest_assignmentNumber_idx" ON "RegistrationRequest"("assignmentNumber");

-- CreateIndex
CREATE INDEX "RegistrationStatusHistory_registrationRequestId_idx" ON "RegistrationStatusHistory"("registrationRequestId");

-- CreateIndex
CREATE INDEX "RegistrationStatusHistory_status_idx" ON "RegistrationStatusHistory"("status");

-- CreateIndex
CREATE INDEX "RegistrationStatusHistory_createdAt_idx" ON "RegistrationStatusHistory"("createdAt");

-- AddForeignKey
ALTER TABLE "RegistrationStatusHistory" ADD CONSTRAINT "RegistrationStatusHistory_registrationRequestId_fkey"
FOREIGN KEY ("registrationRequestId") REFERENCES "RegistrationRequest"("id") ON DELETE CASCADE ON UPDATE CASCADE;
