-- CreateEnum
CREATE TYPE "ExonerationWorkflowStatus" AS ENUM (
    'SUBMITTED',
    'AUTO_VERIFIED',
    'DPCT_VALIDATED',
    'CUSTOMS_VALIDATED',
    'REJECTED',
    'ISSUED',
    'NOTIFIED'
);

-- CreateEnum
CREATE TYPE "ExonerationValidationDecision" AS ENUM ('APPROVE', 'REJECT');

-- CreateTable
CREATE TABLE "ExonerationRequest" (
    "id" TEXT NOT NULL,
    "dossierNumber" TEXT NOT NULL,
    "applicantFirstName" TEXT NOT NULL,
    "applicantLastName" TEXT NOT NULL,
    "applicantEmail" TEXT NOT NULL,
    "applicantPhone" TEXT,
    "organization" TEXT,
    "titleType" TEXT NOT NULL,
    "requestReason" TEXT NOT NULL,
    "supportingDocuments" TEXT NOT NULL,
    "currentStatus" "ExonerationWorkflowStatus" NOT NULL DEFAULT 'SUBMITTED',
    "automaticVerification" JSONB,
    "dpctDecision" "ExonerationValidationDecision",
    "dpctNotes" TEXT,
    "customsDecision" "ExonerationValidationDecision",
    "customsNotes" TEXT,
    "rejectionReason" TEXT,
    "rejectionNotifiedAt" TIMESTAMP(3),
    "exonerationNumber" TEXT,
    "issuedAt" TIMESTAMP(3),
    "expiryDate" TIMESTAMP(3),
    "notifiedAt" TIMESTAMP(3),
    "createdBy" TEXT NOT NULL,
    "dpctValidatedBy" TEXT,
    "customsValidatedBy" TEXT,
    "issuedBy" TEXT,
    "notifiedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ExonerationRequest_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ExonerationStatusHistory" (
    "id" TEXT NOT NULL,
    "exonerationRequestId" TEXT NOT NULL,
    "status" "ExonerationWorkflowStatus" NOT NULL,
    "changedBy" TEXT NOT NULL,
    "notes" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ExonerationStatusHistory_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ExonerationRequest_dossierNumber_key" ON "ExonerationRequest"("dossierNumber");

-- CreateIndex
CREATE UNIQUE INDEX "ExonerationRequest_exonerationNumber_key" ON "ExonerationRequest"("exonerationNumber");

-- CreateIndex
CREATE INDEX "ExonerationRequest_currentStatus_idx" ON "ExonerationRequest"("currentStatus");

-- CreateIndex
CREATE INDEX "ExonerationRequest_createdBy_idx" ON "ExonerationRequest"("createdBy");

-- CreateIndex
CREATE INDEX "ExonerationRequest_applicantEmail_idx" ON "ExonerationRequest"("applicantEmail");

-- CreateIndex
CREATE INDEX "ExonerationRequest_exonerationNumber_idx" ON "ExonerationRequest"("exonerationNumber");

-- CreateIndex
CREATE INDEX "ExonerationStatusHistory_exonerationRequestId_idx" ON "ExonerationStatusHistory"("exonerationRequestId");

-- CreateIndex
CREATE INDEX "ExonerationStatusHistory_status_idx" ON "ExonerationStatusHistory"("status");

-- CreateIndex
CREATE INDEX "ExonerationStatusHistory_createdAt_idx" ON "ExonerationStatusHistory"("createdAt");

-- AddForeignKey
ALTER TABLE "ExonerationStatusHistory"
ADD CONSTRAINT "ExonerationStatusHistory_exonerationRequestId_fkey"
FOREIGN KEY ("exonerationRequestId")
REFERENCES "ExonerationRequest"("id")
ON DELETE CASCADE
ON UPDATE CASCADE;
