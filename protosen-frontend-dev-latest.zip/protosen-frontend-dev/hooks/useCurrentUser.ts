"use client";
import { useSession } from "next-auth/react";

export default function useCurrentUser() {
  const session = useSession();
  const user = session?.data?.user;
  const normalizedRole = String(user?.role || "").toLowerCase();
  const isAdmin = normalizedRole === "admin";
  const isSuperAdmin =
    normalizedRole === "super_admin" ||
    normalizedRole === "superadmin" ||
    normalizedRole === "super-admin";
  const isUser = user?.role === "user";
  const fullName = user ? user?.first_name + " " + user?.last_name : "User";
  const currentUser = {
    ...user,
    fullName,
    isAdmin,
    isSuperAdmin,
    isUser,
  };
  return currentUser;
}
